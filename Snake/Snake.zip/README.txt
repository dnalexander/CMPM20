     _______..__   __.      ___       __  ___  _______    ____    __    ____  ___      .______          _______.   
    /       ||  \ |  |     /   \     |  |/  / |   ____|   \   \  /  \  /   / /   \     |   _  \        /       |   
   |   (----`|   \|  |    /  ^  \    |  '  /  |  |__       \   \/    \/   / /  ^  \    |  |_)  |      |   (----`   
    \   \    |  . `  |   /  /_\  \   |    <   |   __|       \            / /  /_\  \   |      /        \   \       
.----)   |   |  |\   |  /  _____  \  |  .  \  |  |____       \    /\    / /  _____  \  |  |\  \----.----)   |      
|_______/    |__| \__| /__/     \__\ |__|\__\ |_______|       \__/  \__/ /__/     \__\ | _| `._____|_______/       
                                                                                                                   
This is a two-player variant of the classic game, Snake.
The images used in the game are stored on UCSC's Unix timeshare.

Try and get to the food before your opponent to grow your own score!

Player 1 controls:
Up ---- W
Left -- A
Down -- S
Right-- D

Player 2 controls:
Up ---- Up Arrow Key
Left -- Left Arrow Key
Down -- Down Arrow Key
Right-- Right Arrow Key